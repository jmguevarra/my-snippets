<?php
namespace Elementor;

class Custom_Team extends Widget_Base {
	
	public function get_name() {
		return 'custom-team';
	}
	
	public function get_title() {
		return 'Custom Team';
	}
	
	public function get_icon() {
		return 'eicon-person';
	}
	
	public function get_categories() {
		return [ 'basic' ];
	}
	
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'elementor' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'profile',
			[
				'label' => __( 'Profile', 'elementor' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				]
			]
		);

		$repeater->add_control(
			'name', [
				'label' => __( 'Name', 'elementor' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'position', [
				'label' => __( 'Position', 'elementor' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title', [
				'label' => __( 'Other Information', 'elementor' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);

		


		// $this->add_control(
		// 	'logo_style',
		// 	[
		// 		'label' => __( 'Logo Style', 'elementor' ),
		// 		'type' => \Elementor\Controls_Manager::SELECT,
		// 		'options' => [
		// 			'two' => __( 'Two Column', 'elementor' ),
		// 			'three' => __( 'Three Column', 'elementor' ),
		// 		],
		// 		'default' => 'two',
		// 	]
		// );


		$this->add_control(
			'list',
			[
				'label' => __( 'Team List', 'elementor' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( $settings['list'] ) {
			echo '<div class="team-container">';
			foreach (  $settings['list'] as $item ) {
				echo '<div class="team-box">';
				if($item['profile']['url']){
					echo '<img src="'.$item['profile']['url'].'" alt="'.$item['name'].'">';
				} else {
					echo '<img src="/wp-content/uploads/2021/03/default-team-profile.jpg" alt="'.$item['name'].'">';
				}
				echo '<div class="team-name">'.$item['name'].'</div>';
				if($item['position']){
					echo '<div class="team-position">'.$item['position'].'</div>';
				}
				if($item['title']){
					echo '<div class="team-title">'.$item['title'].'</div>';
				}
				echo '</div>';
			}
			echo '</div>';
		}
	}

	protected function _content_template() {

	}
}